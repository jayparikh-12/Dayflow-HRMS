-- This script will be used to seed initial admin user after first signup
-- Note: This is for reference. The first user should sign up through the UI
-- and then be manually promoted to admin, or set role='admin' in signup metadata

-- Example: Update existing user to admin (run this after creating your first account)
-- UPDATE public.profiles SET role = 'admin', department = 'Administration', position = 'System Administrator' WHERE email = 'your-admin-email@example.com';
