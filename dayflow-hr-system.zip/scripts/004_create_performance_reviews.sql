-- Create performance reviews table
CREATE TABLE IF NOT EXISTS public.performance_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES auth.users(id),
  review_period TEXT NOT NULL,
  review_date DATE NOT NULL,
  overall_rating INTEGER CHECK (overall_rating >= 1 AND overall_rating <= 5),
  technical_skills INTEGER CHECK (technical_skills >= 1 AND technical_skills <= 5),
  communication INTEGER CHECK (communication >= 1 AND communication <= 5),
  teamwork INTEGER CHECK (teamwork >= 1 AND teamwork <= 5),
  productivity INTEGER CHECK (productivity >= 1 AND productivity <= 5),
  strengths TEXT,
  areas_for_improvement TEXT,
  goals TEXT,
  comments TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'acknowledged')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.performance_reviews ENABLE ROW LEVEL SECURITY;

-- Policies for performance reviews
CREATE POLICY "Employees can view their own reviews"
  ON public.performance_reviews FOR SELECT
  USING (auth.uid() = employee_id);

CREATE POLICY "Reviewers can view reviews they created"
  ON public.performance_reviews FOR SELECT
  USING (auth.uid() = reviewer_id);

CREATE POLICY "Admins can view all reviews"
  ON public.performance_reviews FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can create reviews"
  ON public.performance_reviews FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Reviewers can update their draft reviews"
  ON public.performance_reviews FOR UPDATE
  USING (auth.uid() = reviewer_id AND status = 'draft');

CREATE POLICY "Admins can update any review"
  ON public.performance_reviews FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Employees can acknowledge their reviews"
  ON public.performance_reviews FOR UPDATE
  USING (auth.uid() = employee_id AND status = 'submitted')
  WITH CHECK (status = 'acknowledged');
