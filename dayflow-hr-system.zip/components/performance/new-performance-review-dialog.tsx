"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import { Plus } from "lucide-react"
import { Slider } from "@/components/ui/slider"

interface NewPerformanceReviewDialogProps {
  employees: Array<{ id: string; full_name: string; position: string | null }>
  reviewerId: string
  children?: React.ReactNode
}

export function NewPerformanceReviewDialog({ employees, reviewerId, children }: NewPerformanceReviewDialogProps) {
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [employeeId, setEmployeeId] = useState("")
  const [reviewPeriod, setReviewPeriod] = useState("")
  const [reviewDate, setReviewDate] = useState("")
  const [technicalSkills, setTechnicalSkills] = useState([3])
  const [communication, setCommunication] = useState([3])
  const [teamwork, setTeamwork] = useState([3])
  const [productivity, setProductivity] = useState([3])
  const [strengths, setStrengths] = useState("")
  const [areasForImprovement, setAreasForImprovement] = useState("")
  const [goals, setGoals] = useState("")
  const [comments, setComments] = useState("")
  const router = useRouter()
  const supabase = createClient()

  const overallRating = Math.round((technicalSkills[0] + communication[0] + teamwork[0] + productivity[0]) / 4)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const { error } = await supabase.from("performance_reviews").insert({
        employee_id: employeeId,
        reviewer_id: reviewerId,
        review_period: reviewPeriod,
        review_date: reviewDate,
        overall_rating: overallRating,
        technical_skills: technicalSkills[0],
        communication: communication[0],
        teamwork: teamwork[0],
        productivity: productivity[0],
        strengths,
        areas_for_improvement: areasForImprovement,
        goals,
        comments,
        status: "submitted",
      })

      if (error) throw error

      toast.success("Performance review created successfully!")
      setOpen(false)
      router.refresh()

      // Reset form
      setEmployeeId("")
      setReviewPeriod("")
      setReviewDate("")
      setTechnicalSkills([3])
      setCommunication([3])
      setTeamwork([3])
      setProductivity([3])
      setStrengths("")
      setAreasForImprovement("")
      setGoals("")
      setComments("")
    } catch (error) {
      toast.error("Failed to create performance review")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Review
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Performance Review</DialogTitle>
          <DialogDescription>Evaluate employee performance across multiple criteria</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="employee">Employee</Label>
            <Select value={employeeId} onValueChange={setEmployeeId} required>
              <SelectTrigger id="employee">
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map((emp) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.full_name} {emp.position && `- ${emp.position}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="review-period">Review Period</Label>
              <Input
                id="review-period"
                placeholder="e.g., Q1 2025"
                value={reviewPeriod}
                onChange={(e) => setReviewPeriod(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="review-date">Review Date</Label>
              <Input
                id="review-date"
                type="date"
                value={reviewDate}
                onChange={(e) => setReviewDate(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-4 border rounded-lg p-4">
            <h3 className="font-medium">Performance Ratings (1-5)</h3>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Technical Skills</Label>
                  <span className="text-sm font-medium">{technicalSkills[0]}</span>
                </div>
                <Slider min={1} max={5} step={1} value={technicalSkills} onValueChange={setTechnicalSkills} />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Communication</Label>
                  <span className="text-sm font-medium">{communication[0]}</span>
                </div>
                <Slider min={1} max={5} step={1} value={communication} onValueChange={setCommunication} />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Teamwork</Label>
                  <span className="text-sm font-medium">{teamwork[0]}</span>
                </div>
                <Slider min={1} max={5} step={1} value={teamwork} onValueChange={setTeamwork} />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Productivity</Label>
                  <span className="text-sm font-medium">{productivity[0]}</span>
                </div>
                <Slider min={1} max={5} step={1} value={productivity} onValueChange={setProductivity} />
              </div>

              <div className="pt-2 border-t">
                <div className="flex items-center justify-between">
                  <Label className="font-semibold">Overall Rating</Label>
                  <span className="text-lg font-bold">{overallRating}/5</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="strengths">Strengths</Label>
            <Textarea
              id="strengths"
              placeholder="What does this employee do well?"
              value={strengths}
              onChange={(e) => setStrengths(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="areas">Areas for Improvement</Label>
            <Textarea
              id="areas"
              placeholder="Where can this employee grow?"
              value={areasForImprovement}
              onChange={(e) => setAreasForImprovement(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="goals">Goals for Next Period</Label>
            <Textarea
              id="goals"
              placeholder="What should be the focus moving forward?"
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="comments">Additional Comments</Label>
            <Textarea
              id="comments"
              placeholder="Any other observations or notes..."
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Creating..." : "Create Review"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
