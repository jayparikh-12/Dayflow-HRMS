"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { format } from "date-fns"
import { Star, User } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import { useState } from "react"

interface ReviewCardProps {
  review: {
    id: string
    employee_id: string
    review_period: string
    review_date: string
    overall_rating: number
    technical_skills: number
    communication: number
    teamwork: number
    productivity: number
    strengths: string | null
    areas_for_improvement: string | null
    goals: string | null
    comments: string | null
    status: string
    employee: { id: string; full_name: string; email: string; position: string | null }
    reviewer: { full_name: string }
  }
  isAdmin: boolean
}

export function ReviewCard({ review, isAdmin }: ReviewCardProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleAcknowledge = async () => {
    setIsLoading(true)
    try {
      const { error } = await supabase
        .from("performance_reviews")
        .update({ status: "acknowledged" })
        .eq("id", review.id)

      if (error) throw error

      toast.success("Review acknowledged!")
      router.refresh()
    } catch (error) {
      toast.error("Failed to acknowledge review")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <User className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{review.employee.full_name}</CardTitle>
              <CardDescription>
                {review.employee.position || "Team Member"} • {review.review_period}
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={review.status === "acknowledged" ? "default" : "secondary"} className="capitalize">
              {review.status}
            </Badge>
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="font-semibold">{review.overall_rating}/5</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Reviewed by {review.reviewer.full_name}</span>
          <span>{format(new Date(review.review_date), "MMM dd, yyyy")}</span>
        </div>

        <Separator />

        {/* Rating Breakdown */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Performance Breakdown</h4>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span>Technical Skills</span>
                <span className="font-medium">{review.technical_skills}/5</span>
              </div>
              <Progress value={(review.technical_skills / 5) * 100} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span>Communication</span>
                <span className="font-medium">{review.communication}/5</span>
              </div>
              <Progress value={(review.communication / 5) * 100} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span>Teamwork</span>
                <span className="font-medium">{review.teamwork}/5</span>
              </div>
              <Progress value={(review.teamwork / 5) * 100} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span>Productivity</span>
                <span className="font-medium">{review.productivity}/5</span>
              </div>
              <Progress value={(review.productivity / 5) * 100} />
            </div>
          </div>
        </div>

        <Separator />

        {/* Detailed Feedback */}
        <div className="space-y-3">
          {review.strengths && (
            <div>
              <h4 className="text-sm font-medium mb-1">Strengths</h4>
              <p className="text-sm text-muted-foreground">{review.strengths}</p>
            </div>
          )}
          {review.areas_for_improvement && (
            <div>
              <h4 className="text-sm font-medium mb-1">Areas for Improvement</h4>
              <p className="text-sm text-muted-foreground">{review.areas_for_improvement}</p>
            </div>
          )}
          {review.goals && (
            <div>
              <h4 className="text-sm font-medium mb-1">Goals for Next Period</h4>
              <p className="text-sm text-muted-foreground">{review.goals}</p>
            </div>
          )}
          {review.comments && (
            <div>
              <h4 className="text-sm font-medium mb-1">Additional Comments</h4>
              <p className="text-sm text-muted-foreground">{review.comments}</p>
            </div>
          )}
        </div>

        {/* Acknowledge Button for Employees */}
        {!isAdmin && review.status === "submitted" && (
          <>
            <Separator />
            <Button onClick={handleAcknowledge} disabled={isLoading} className="w-full">
              {isLoading ? "Acknowledging..." : "Acknowledge Review"}
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  )
}
