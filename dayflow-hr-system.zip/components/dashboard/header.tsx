import { createClient } from "@/lib/supabase/server"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export async function DashboardHeader() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  // Get profile data
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const initials =
    profile?.full_name
      ?.split(" ")
      .map((n: string) => n[0])
      .join("")
      .toUpperCase() || "U"

  return (
    <header className="flex h-16 items-center justify-between border-b bg-background px-6">
      <div>
        <h1 className="text-xl font-semibold">Welcome back, {profile?.full_name || "User"}</h1>
        <p className="text-sm text-muted-foreground">
          {profile?.position || "Team Member"} {profile?.department && `• ${profile.department}`}
        </p>
      </div>
      <div className="flex items-center gap-4">
        <Badge variant={profile?.role === "admin" ? "default" : "secondary"} className="capitalize">
          {profile?.role || "Employee"}
        </Badge>
        <Avatar>
          <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} alt={profile?.full_name} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}
