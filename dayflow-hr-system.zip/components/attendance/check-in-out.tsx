"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { Clock, LogIn, LogOut } from "lucide-react"

interface CheckInOutProps {
  userId: string
  todayAttendance: {
    id: string
    check_in: string | null
    check_out: string | null
    status: string
  } | null
}

export function CheckInOut({ userId, todayAttendance }: CheckInOutProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleCheckIn = async () => {
    setIsLoading(true)
    try {
      const today = new Date().toISOString().split("T")[0]
      const now = new Date().toISOString()

      const { error } = await supabase.from("attendance").insert({
        user_id: userId,
        date: today,
        check_in: now,
        status: "present",
      })

      if (error) throw error

      toast.success("Checked in successfully!")
      router.refresh()
    } catch (error) {
      toast.error("Failed to check in. Please try again.")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCheckOut = async () => {
    if (!todayAttendance?.id) return

    setIsLoading(true)
    try {
      const now = new Date().toISOString()

      const { error } = await supabase
        .from("attendance")
        .update({
          check_out: now,
        })
        .eq("id", todayAttendance.id)

      if (error) throw error

      toast.success("Checked out successfully!")
      router.refresh()
    } catch (error) {
      toast.error("Failed to check out. Please try again.")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!todayAttendance || !todayAttendance.check_in) {
    return (
      <div className="flex flex-col items-center gap-6">
        <div className="flex items-center gap-3 text-muted-foreground">
          <Clock className="h-12 w-12" />
          <div>
            <p className="text-lg font-medium">Ready to start your day?</p>
            <p className="text-sm">Click the button below to check in</p>
          </div>
        </div>
        <Button size="lg" onClick={handleCheckIn} disabled={isLoading} className="min-w-[200px]">
          <LogIn className="mr-2 h-5 w-5" />
          {isLoading ? "Checking In..." : "Check In"}
        </Button>
      </div>
    )
  }

  if (todayAttendance.check_out) {
    return (
      <div className="flex flex-col items-center gap-6">
        <div className="grid gap-4 w-full max-w-md">
          <Card className="p-4 bg-green-50 border-green-200">
            <div className="flex items-center gap-3">
              <LogIn className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-900">Checked In</p>
                <p className="text-sm text-green-700">{format(new Date(todayAttendance.check_in), "hh:mm a")}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-blue-50 border-blue-200">
            <div className="flex items-center gap-3">
              <LogOut className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-900">Checked Out</p>
                <p className="text-sm text-blue-700">{format(new Date(todayAttendance.check_out), "hh:mm a")}</p>
              </div>
            </div>
          </Card>
        </div>
        <p className="text-sm text-muted-foreground">You've completed your attendance for today</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <Card className="p-4 bg-green-50 border-green-200 w-full max-w-md">
        <div className="flex items-center gap-3">
          <LogIn className="h-5 w-5 text-green-600" />
          <div>
            <p className="text-sm font-medium text-green-900">Checked In</p>
            <p className="text-sm text-green-700">{format(new Date(todayAttendance.check_in), "hh:mm a")}</p>
          </div>
        </div>
      </Card>
      <div className="flex items-center gap-3 text-muted-foreground">
        <Clock className="h-8 w-8" />
        <p className="text-sm">Don't forget to check out when you're done!</p>
      </div>
      <Button
        size="lg"
        onClick={handleCheckOut}
        disabled={isLoading}
        variant="outline"
        className="min-w-[200px] bg-transparent"
      >
        <LogOut className="mr-2 h-5 w-5" />
        {isLoading ? "Checking Out..." : "Check Out"}
      </Button>
    </div>
  )
}
