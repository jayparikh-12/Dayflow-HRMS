import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { NewPerformanceReviewDialog } from "@/components/performance/new-performance-review-dialog"
import { ReviewCard } from "@/components/performance/review-card"
import { Star, TrendingUp } from "lucide-react"

export default async function PerformancePage({ searchParams }: { searchParams: Promise<{ employee?: string }> }) {
  const supabase = await createClient()
  const params = await searchParams

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get current user profile
  const { data: currentProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const isAdmin = currentProfile?.role === "admin"
  const targetUserId = isAdmin && params.employee ? params.employee : user.id

  // Fetch reviews
  let reviewQuery = supabase
    .from("performance_reviews")
    .select(
      `
      *,
      employee:profiles!performance_reviews_employee_id_fkey(id, full_name, email, position),
      reviewer:profiles!performance_reviews_reviewer_id_fkey(full_name)
    `,
    )
    .order("review_date", { ascending: false })

  if (!isAdmin || params.employee) {
    reviewQuery = reviewQuery.eq("employee_id", targetUserId)
  }

  const { data: reviews } = await reviewQuery

  // Calculate average rating
  const submittedReviews = reviews?.filter((r) => r.status === "submitted" || r.status === "acknowledged") || []
  const avgRating =
    submittedReviews.length > 0
      ? (submittedReviews.reduce((sum, r) => sum + (r.overall_rating || 0), 0) / submittedReviews.length).toFixed(1)
      : "N/A"

  // Get all employees for admin
  const { data: employees } = isAdmin
    ? await supabase.from("profiles").select("id, full_name, position").eq("role", "employee").order("full_name")
    : { data: null }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            {isAdmin ? "Performance Reviews" : "My Performance Reviews"}
          </h2>
          <p className="text-muted-foreground">
            {isAdmin ? "Conduct and manage employee performance reviews" : "View your performance evaluations"}
          </p>
        </div>
        {isAdmin && <NewPerformanceReviewDialog employees={employees || []} reviewerId={user.id} />}
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reviews?.length || 0}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgRating}</div>
            <p className="text-xs text-muted-foreground">Out of 5.0</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Acknowledgment</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {reviews?.filter((r) => r.status === "submitted" && r.employee_id === user.id).length || 0}
            </div>
            <p className="text-xs text-muted-foreground">Reviews to acknowledge</p>
          </CardContent>
        </Card>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews && reviews.length > 0 ? (
          reviews.map((review) => <ReviewCard key={review.id} review={review} isAdmin={isAdmin} />)
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <Star className="h-12 w-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No performance reviews found.</p>
              {isAdmin && (
                <NewPerformanceReviewDialog employees={employees || []} reviewerId={user.id}>
                  <Button>Create First Review</Button>
                </NewPerformanceReviewDialog>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
