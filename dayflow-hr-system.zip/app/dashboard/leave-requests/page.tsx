import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { NewLeaveRequestDialog } from "@/components/leave/new-leave-request-dialog"
import { LeaveApprovalActions } from "@/components/leave/leave-approval-actions"
import { format } from "date-fns"
import { CalendarDays, CheckCircle2, Clock, XCircle } from "lucide-react"

export default async function LeaveRequestsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get current user profile
  const { data: currentProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const isAdmin = currentProfile?.role === "admin"

  // Fetch leave requests based on role
  let leaveQuery = supabase
    .from("leave_requests")
    .select("*, profiles!leave_requests_user_id_fkey(full_name, email)")
    .order("created_at", { ascending: false })

  if (!isAdmin) {
    leaveQuery = leaveQuery.eq("user_id", user.id)
  }

  const { data: allLeaves } = await leaveQuery

  // Categorize leaves
  const pendingLeaves = allLeaves?.filter((l) => l.status === "pending") || []
  const approvedLeaves = allLeaves?.filter((l) => l.status === "approved") || []
  const rejectedLeaves = allLeaves?.filter((l) => l.status === "rejected") || []

  // Stats
  const totalPending = pendingLeaves.length
  const totalApproved = approvedLeaves.length
  const totalRejected = rejectedLeaves.length

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Leave Requests</h2>
          <p className="text-muted-foreground">
            {isAdmin ? "Manage team leave requests" : "Submit and track your leave requests"}
          </p>
        </div>
        {!isAdmin && <NewLeaveRequestDialog userId={user.id} />}
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPending}</div>
            <p className="text-xs text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalApproved}</div>
            <p className="text-xs text-muted-foreground">Approved requests</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejected</CardTitle>
            <XCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalRejected}</div>
            <p className="text-xs text-muted-foreground">Rejected requests</p>
          </CardContent>
        </Card>
      </div>

      {/* Leave Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Leave Requests</CardTitle>
          <CardDescription>View and manage leave requests</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <LeaveTable leaves={allLeaves || []} isAdmin={isAdmin} currentUserId={user.id} />
            </TabsContent>
            <TabsContent value="pending" className="mt-6">
              <LeaveTable leaves={pendingLeaves} isAdmin={isAdmin} currentUserId={user.id} />
            </TabsContent>
            <TabsContent value="approved" className="mt-6">
              <LeaveTable leaves={approvedLeaves} isAdmin={isAdmin} currentUserId={user.id} />
            </TabsContent>
            <TabsContent value="rejected" className="mt-6">
              <LeaveTable leaves={rejectedLeaves} isAdmin={isAdmin} currentUserId={user.id} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

function LeaveTable({
  leaves,
  isAdmin,
  currentUserId,
}: {
  leaves: Array<{
    id: string
    user_id: string
    leave_type: string
    start_date: string
    end_date: string
    days_count: number
    reason: string
    status: string
    rejection_reason?: string
    created_at: string
    profiles: { full_name: string; email: string }
  }>
  isAdmin: boolean
  currentUserId: string
}) {
  if (leaves.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <CalendarDays className="h-12 w-12 mx-auto mb-2 opacity-50" />
        <p>No leave requests found.</p>
      </div>
    )
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            {isAdmin && <TableHead>Employee</TableHead>}
            <TableHead>Leave Type</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Days</TableHead>
            <TableHead>Reason</TableHead>
            <TableHead>Status</TableHead>
            {isAdmin && <TableHead>Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {leaves.map((leave) => (
            <TableRow key={leave.id}>
              {isAdmin && <TableCell className="font-medium">{leave.profiles.full_name}</TableCell>}
              <TableCell className="capitalize">{leave.leave_type}</TableCell>
              <TableCell>{format(new Date(leave.start_date), "MMM dd, yyyy")}</TableCell>
              <TableCell>{format(new Date(leave.end_date), "MMM dd, yyyy")}</TableCell>
              <TableCell>{leave.days_count}</TableCell>
              <TableCell className="max-w-xs truncate">{leave.reason}</TableCell>
              <TableCell>
                <Badge
                  variant={
                    leave.status === "approved" ? "default" : leave.status === "pending" ? "secondary" : "destructive"
                  }
                  className="capitalize"
                >
                  {leave.status}
                </Badge>
                {leave.status === "rejected" && leave.rejection_reason && (
                  <p className="text-xs text-muted-foreground mt-1 max-w-xs truncate">{leave.rejection_reason}</p>
                )}
              </TableCell>
              {isAdmin && (
                <TableCell>{leave.status === "pending" && <LeaveApprovalActions leaveId={leave.id} />}</TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
