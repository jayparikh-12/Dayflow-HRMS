import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CheckInOut } from "@/components/attendance/check-in-out"
import { format } from "date-fns"
import { Clock, CalendarIcon } from "lucide-react"

export default async function AttendancePage({ searchParams }: { searchParams: Promise<{ employee?: string }> }) {
  const supabase = await createClient()
  const params = await searchParams

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get current user profile
  const { data: currentProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const isAdmin = currentProfile?.role === "admin"
  const targetUserId = isAdmin && params.employee ? params.employee : user.id

  // Fetch today's attendance
  const today = new Date().toISOString().split("T")[0]
  const { data: todayAttendance } = await supabase
    .from("attendance")
    .select("*")
    .eq("user_id", targetUserId)
    .eq("date", today)
    .single()

  // Fetch attendance history (last 30 days)
  const thirtyDaysAgo = new Date()
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

  let attendanceQuery = supabase
    .from("attendance")
    .select("*, profiles!attendance_user_id_fkey(full_name)")
    .gte("date", thirtyDaysAgo.toISOString().split("T")[0])
    .order("date", { ascending: false })

  if (!isAdmin || params.employee) {
    attendanceQuery = attendanceQuery.eq("user_id", targetUserId)
  }

  const { data: attendanceHistory } = await attendanceQuery

  // Calculate stats
  const presentDays = attendanceHistory?.filter((a) => a.status === "present").length || 0
  const lateDays = attendanceHistory?.filter((a) => a.status === "late").length || 0
  const absentDays = attendanceHistory?.filter((a) => a.status === "absent").length || 0

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">{isAdmin ? "Attendance Management" : "My Attendance"}</h2>
        <p className="text-muted-foreground">
          {isAdmin ? "Track and manage team attendance" : "Check in, check out, and view your attendance history"}
        </p>
      </div>

      {/* Check In/Out Card - Only show for own attendance */}
      {!params.employee && (
        <Card>
          <CardHeader>
            <CardTitle>Today's Attendance</CardTitle>
            <CardDescription>{format(new Date(), "EEEE, MMMM dd, yyyy")}</CardDescription>
          </CardHeader>
          <CardContent>
            <CheckInOut userId={user.id} todayAttendance={todayAttendance} />
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Present Days</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{presentDays}</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Late Days</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{lateDays}</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Absent Days</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{absentDays}</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
      </div>

      {/* Attendance History */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance History</CardTitle>
          <CardDescription>Your attendance records for the last 30 days</CardDescription>
        </CardHeader>
        <CardContent>
          {attendanceHistory && attendanceHistory.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    {isAdmin && !params.employee && <TableHead>Employee</TableHead>}
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendanceHistory.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{format(new Date(record.date), "MMM dd, yyyy")}</TableCell>
                      {isAdmin && !params.employee && (
                        <TableCell>{(record.profiles as { full_name: string })?.full_name || "Unknown"}</TableCell>
                      )}
                      <TableCell>{record.check_in ? format(new Date(record.check_in), "hh:mm a") : "-"}</TableCell>
                      <TableCell>{record.check_out ? format(new Date(record.check_out), "hh:mm a") : "-"}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            record.status === "present"
                              ? "default"
                              : record.status === "late"
                                ? "secondary"
                                : "destructive"
                          }
                          className="capitalize"
                        >
                          {record.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{record.notes || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">No attendance records found.</div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
