import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarDays, CheckCircle2, Clock, Users } from "lucide-react"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Get stats based on role
  let stats = []

  if (profile?.role === "admin") {
    // Admin stats
    const { count: employeeCount } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("role", "employee")

    const { count: pendingLeaveCount } = await supabase
      .from("leave_requests")
      .select("*", { count: "exact", head: true })
      .eq("status", "pending")

    const today = new Date().toISOString().split("T")[0]
    const { count: todayAttendanceCount } = await supabase
      .from("attendance")
      .select("*", { count: "exact", head: true })
      .eq("date", today)
      .eq("status", "present")

    stats = [
      {
        title: "Total Employees",
        value: employeeCount || 0,
        description: "Active team members",
        icon: Users,
      },
      {
        title: "Pending Leaves",
        value: pendingLeaveCount || 0,
        description: "Awaiting approval",
        icon: CalendarDays,
      },
      {
        title: "Today's Attendance",
        value: todayAttendanceCount || 0,
        description: "Employees present",
        icon: CheckCircle2,
      },
    ]
  } else {
    // Employee stats
    const { count: myLeaveCount } = await supabase
      .from("leave_requests")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("status", "pending")

    const today = new Date().toISOString().split("T")[0]
    const { data: todayAttendance } = await supabase
      .from("attendance")
      .select("*")
      .eq("user_id", user.id)
      .eq("date", today)
      .single()

    const { count: myReviewCount } = await supabase
      .from("performance_reviews")
      .select("*", { count: "exact", head: true })
      .eq("employee_id", user.id)

    stats = [
      {
        title: "Pending Leave Requests",
        value: myLeaveCount || 0,
        description: "Awaiting approval",
        icon: CalendarDays,
      },
      {
        title: "Today's Status",
        value: todayAttendance?.status || "Not Checked In",
        description: todayAttendance?.check_in
          ? `Checked in at ${new Date(todayAttendance.check_in).toLocaleTimeString()}`
          : "Check in to start your day",
        icon: Clock,
      },
      {
        title: "Performance Reviews",
        value: myReviewCount || 0,
        description: "Total reviews received",
        icon: CheckCircle2,
      },
    ]
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">
          {profile?.role === "admin" ? "Admin Dashboard" : "My Dashboard"}
        </h2>
        <p className="text-muted-foreground">
          {profile?.role === "admin"
            ? "Overview of your organization's HR metrics"
            : "Track your attendance, leaves, and performance"}
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            {profile?.role === "admin" ? "Common administrative tasks" : "Frequently used features"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            {profile?.role === "admin"
              ? "Navigate using the sidebar to manage employees, review attendance, approve leave requests, and conduct performance reviews."
              : "Use the sidebar to check in/out, request time off, and view your performance reviews."}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
