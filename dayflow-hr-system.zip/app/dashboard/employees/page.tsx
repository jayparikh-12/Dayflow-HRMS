import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, Phone, Briefcase, Calendar } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

export default async function EmployeesPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string }>
}) {
  const supabase = await createClient()
  const params = await searchParams

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get current user profile
  const { data: currentProfile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  // Only admins can see full employee directory
  if (currentProfile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch all employees
  let query = supabase.from("profiles").select("*").order("full_name", { ascending: true })

  // Apply search filter if present
  if (params.search) {
    query = query.or(
      `full_name.ilike.%${params.search}%,email.ilike.%${params.search}%,department.ilike.%${params.search}%,position.ilike.%${params.search}%`,
    )
  }

  const { data: employees } = await query

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Employee Directory</h2>
          <p className="text-muted-foreground">Manage and view all team members</p>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle>Search Employees</CardTitle>
          <CardDescription>Find employees by name, email, department, or position</CardDescription>
        </CardHeader>
        <CardContent>
          <form action="/dashboard/employees" method="get">
            <div className="flex gap-2">
              <Input name="search" placeholder="Search employees..." defaultValue={params.search} className="flex-1" />
              <Button type="submit">Search</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Employee Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {employees?.map((employee) => {
          const initials = employee.full_name
            ?.split(" ")
            .map((n: string) => n[0])
            .join("")
            .toUpperCase()

          return (
            <Card key={employee.id} className="overflow-hidden">
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={employee.avatar_url || "/placeholder.svg"} alt={employee.full_name} />
                    <AvatarFallback className="text-lg">{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-lg truncate">{employee.full_name}</h3>
                    <p className="text-sm text-muted-foreground truncate">{employee.position || "Team Member"}</p>
                    <Badge variant={employee.role === "admin" ? "default" : "secondary"} className="mt-2 capitalize">
                      {employee.role}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <span className="truncate">{employee.email}</span>
                </div>
                {employee.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span>{employee.phone}</span>
                  </div>
                )}
                {employee.department && (
                  <div className="flex items-center gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span>{employee.department}</span>
                  </div>
                )}
                {employee.hire_date && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span>Joined {format(new Date(employee.hire_date), "MMM dd, yyyy")}</span>
                  </div>
                )}
                <Button asChild className="w-full mt-4 bg-transparent" variant="outline">
                  <Link href={`/dashboard/employees/${employee.id}`}>View Profile</Link>
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {!employees || employees.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">
              {params.search ? "No employees found matching your search." : "No employees found."}
            </p>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
